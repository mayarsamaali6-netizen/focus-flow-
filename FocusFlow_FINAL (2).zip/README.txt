FocusFlow FINAL
================
A from-scratch multilingual study/focus web app.

Included:
- Dashboard with real daily progress and weekly chart
- Pomodoro focus timer with 25/45/60 presets
- Generated Rain, Cafe, Nature and White Noise ambience
- Flashcards with flip + review tracking
- Active Recall history
- Study Planner with dates, durations, types, completion and deletion
- Reading list
- Writing space with autosave
- Practice-to-focus flow
- Progress history
- Local account profile
- English / Français / العربية + RTL
- Export / Restore backup
- Local persistence using browser storage
- Responsive desktop/mobile UI

Important:
The account is local to the browser/device. No server or real online authentication is included.
All app data is stored locally until the user resets or clears browser storage.
